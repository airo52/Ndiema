export default [
  {
    id: '1',
    title: 'This is the title no one.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
  },
  {
    id: '2',
    title: 'This is the title no two.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
  },
  {
    id: '3',
    title: 'This is the title no three.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
  },
  {
    id: '4',
    title: 'This is the title no four.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
  },
  {
    id: '5',
    title: 'This is the title no five.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
  },
  {
    id: '6',
    title: 'This is the title no six.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'tech',
  },
  {
    id: '7',
    title: 'This is the title no seven.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'tech',
  },
  {
    id: '8',
    title: 'This is the title no eight.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'tech',
  },
  {
    id: '9',
    title: 'This is the title no nine.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
    category: 'tech',
  },
  {
    id: '10',
    title: 'This is the title no ten.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'tech',
  },
  {
    id: '11',
    title: 'This is the title no eleven.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'political',
  },
  {
    id: '12',
    title: 'This is the title no twelve.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'political',
  },
  {
    id: '13',
    title: 'This is the title no thirteen.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'political',
  },
  {
    id: '14',
    title: 'This is the title no fourteen.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
    category: 'political',
  },
  {
    id: '15',
    title: 'This is the title no fifteen.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'political',
  },
  {
    id: '16',
    title: 'This is the title no sixteen.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'entertainment',
  },
  {
    id: '17',
    title: 'This is the title no seventeen.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'entertainment',
  },
  {
    id: '18',
    title: 'This is the title no eighteen.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'entertainment',
  },
  {
    id: '19',
    title: 'This is the title no nineteen.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'breaking-news',
    category: 'entertainment',
  },
  {
    id: '20',
    title: 'This is the title no twenty.',
    desc:
      'Desc is the short form of description and this format is the actual same as our real database.',
    thumbnail: 'http://lorempixel.com/400/200/',
    category: 'entertainment',
  },
];
